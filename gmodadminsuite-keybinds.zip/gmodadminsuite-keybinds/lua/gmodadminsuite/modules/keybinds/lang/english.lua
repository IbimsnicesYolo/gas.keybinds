return {
	Name = "English",
	Flag = "flags16/gb.png",
	Phrases = function() return {

		module_name = "Keybinds",

		frozen_player         = "a",
		permissions           = "aa",
		PermissionsTip        = "aaa",
		EnableRainbowPhysgun  = "aaaa",
		NegateFallDamage      = "aaaaa",
		NegateFallDamage_help = "aaaaaa",
		QuickFreeze           = "aaaaaaa",
		QuickFreeze_help      = "aaaaaaaa",
		GodPickup             = "aaaaaaaaa",
		GodPickup_help        = "aaaaaaaaaa",
		ResetVelocity         = "aaaaaaaaaaa",
		ResetVelocity_help    = "aaaaaaaaaaaa",
		StripWeapons          = "aaaaaaaaaaaaa",
		StripWeapons_help     = "aaaaaaaaaaaaaa",

} end }