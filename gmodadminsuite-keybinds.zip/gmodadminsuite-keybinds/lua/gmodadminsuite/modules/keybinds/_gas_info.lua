return {
	DefaultEnabled = true,
	Name = "Keybind Menü",
	Category = GAS.MODULE_CATEGORY_PLAYER_MANAGEMENT,
	Icon = "icon16/wrench_orange.png"

}